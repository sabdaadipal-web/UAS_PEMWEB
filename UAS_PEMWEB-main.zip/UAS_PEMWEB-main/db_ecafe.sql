-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 29 Jun 2026 pada 05.29
-- Versi server: 10.4.25-MariaDB
-- Versi PHP: 8.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_ecafe`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_pesanan`
--

CREATE TABLE `detail_pesanan` (
  `id_detail` int(11) NOT NULL,
  `id_pesanan` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `subtotal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `detail_pesanan`
--

INSERT INTO `detail_pesanan` (`id_detail`, `id_pesanan`, `id_produk`, `qty`, `subtotal`) VALUES
(1, 1, 1, 1, 20000),
(2, 2, 1, 1, 20000),
(3, 3, 2, 1, 10000),
(4, 3, 3, 1, 18000),
(5, 3, 1, 1, 20000),
(6, 4, 2, 1, 10000),
(7, 4, 3, 1, 18000),
(8, 5, 3, 1, 18000),
(9, 5, 2, 1, 10000),
(10, 6, 2, 1, 10000),
(11, 6, 3, 2, 36000),
(12, 7, 2, 2, 20000),
(13, 7, 1, 1, 20000),
(14, 8, 2, 1, 10000),
(15, 8, 3, 1, 18000),
(16, 8, 1, 1, 20000),
(17, 9, 2, 1, 10000),
(18, 9, 1, 1, 20000),
(19, 10, 3, 1, 18000),
(20, 10, 2, 1, 10000),
(21, 11, 3, 1, 18000),
(22, 11, 2, 1, 10000),
(23, 11, 1, 1, 20000),
(24, 12, 2, 1, 10000),
(25, 13, 2, 2, 20000),
(26, 13, 1, 1, 20000),
(27, 14, 2, 1, 10000),
(28, 14, 1, 1, 20000),
(29, 15, 1, 1, 20000),
(30, 15, 2, 1, 10000),
(31, 16, 3, 1, 20000),
(32, 16, 2, 1, 10000),
(33, 17, 1, 1, 20000),
(34, 17, 2, 1, 10000),
(35, 18, 1, 1, 20000),
(36, 18, 2, 1, 10000);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pesanan`
--

CREATE TABLE `pesanan` (
  `id_pesanan` int(11) NOT NULL,
  `tanggal` datetime NOT NULL DEFAULT current_timestamp(),
  `total_harga` int(11) NOT NULL,
  `nama_pelanggan` varchar(100) NOT NULL,
  `tipe_pesanan` enum('Dine In') NOT NULL,
  `status_pesanan` varchar(20) DEFAULT 'Menunggu'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pesanan`
--

INSERT INTO `pesanan` (`id_pesanan`, `tanggal`, `total_harga`, `nama_pelanggan`, `tipe_pesanan`, `status_pesanan`) VALUES
(1, '2026-06-29 00:47:42', 22000, 'Pelanggan Umum', 'Dine In', 'Selesai'),
(2, '2026-06-29 00:56:43', 22000, 'Pelanggan Umum', 'Dine In', 'Selesai'),
(3, '2026-06-29 00:58:49', 52800, 'Pelanggan Umum', 'Dine In', 'Selesai'),
(4, '2026-06-29 01:02:26', 30800, 'Pelanggan Umum', 'Dine In', 'Selesai'),
(5, '2026-06-29 01:04:49', 30800, 'Pelanggan Umum', 'Dine In', 'Selesai'),
(6, '2026-06-29 01:06:36', 50600, 'Pelanggan Umum', 'Dine In', 'Selesai'),
(7, '2026-06-29 01:07:43', 44000, 'Pelanggan Umum', 'Dine In', 'Selesai'),
(8, '2026-06-29 01:10:17', 52800, 'Pelanggan Umum', 'Dine In', 'Selesai'),
(9, '2026-06-29 01:12:25', 33000, 'Pelanggan Umum', 'Dine In', 'Selesai'),
(10, '2026-06-29 11:13:52', 30800, 'Adi', 'Dine In', 'Selesai'),
(11, '2026-06-29 11:20:16', 52800, 'Rafie', 'Dine In', 'Pending'),
(12, '2026-06-29 11:38:38', 11000, 'yusuf', 'Dine In', 'Pending'),
(13, '2026-06-29 11:39:29', 44000, 'dive', 'Dine In', 'Pending'),
(14, '2026-06-29 11:39:51', 33000, 'nanang', 'Dine In', 'Pending'),
(15, '2026-06-29 11:41:17', 33000, 'Deden', 'Dine In', 'Pending'),
(16, '2026-06-29 12:20:58', 33000, 'Deni', 'Dine In', 'Pending'),
(17, '2026-06-29 12:22:54', 33000, 'Daffa', 'Dine In', 'Pending'),
(18, '2026-06-29 12:23:32', 33000, 'Restali', 'Dine In', 'Selesai');

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE `produk` (
  `id_produk` int(11) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `harga` int(11) NOT NULL,
  `stok` int(11) NOT NULL DEFAULT 0,
  `gambar` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`id_produk`, `nama_produk`, `harga`, `stok`, `gambar`) VALUES
(1, 'Matcha Latte', 20000, 8, 'image/6a415e1b01060.jpg'),
(2, 'americano', 10000, 12, 'image/6a41609053e4b.jpg'),
(3, 'cappucino', 20000, 0, 'image/6a4160abeba72.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id_user`, `username`, `password`) VALUES
(1, 'admin', 'admin123');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `detail_pesanan`
--
ALTER TABLE `detail_pesanan`
  ADD PRIMARY KEY (`id_detail`),
  ADD KEY `fk_detail_pesanan` (`id_pesanan`),
  ADD KEY `fk_detail_produk` (`id_produk`);

--
-- Indeks untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  ADD PRIMARY KEY (`id_pesanan`);

--
-- Indeks untuk tabel `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id_produk`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id_user`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `detail_pesanan`
--
ALTER TABLE `detail_pesanan`
  MODIFY `id_detail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  MODIFY `id_pesanan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT untuk tabel `produk`
--
ALTER TABLE `produk`
  MODIFY `id_produk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `detail_pesanan`
--
ALTER TABLE `detail_pesanan`
  ADD CONSTRAINT `fk_detail_pesanan` FOREIGN KEY (`id_pesanan`) REFERENCES `pesanan` (`id_pesanan`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_detail_produk` FOREIGN KEY (`id_produk`) REFERENCES `produk` (`id_produk`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
